# Movie Website

A responsive movie website project was developed.

# Used technologies

- HTML
- CSS
- Java Scrip

# Screenshots

![](1.jpg)

# Video

![](Spiderman_Website_video.mp4)

# GIF

![](Spiderman_Website.gif)

